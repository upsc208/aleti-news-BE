rootProject.name = "news"
