package com.atleti.news

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class AtletiNewsApplication

fun main(args: Array<String>) {
	runApplication<AtletiNewsApplication>(*args)
}
